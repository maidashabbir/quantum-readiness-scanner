
import os
import sys
import argparse
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

RISK_THRESHOLDS = {
    'RSA': {'min_bits': 3072},
    'EC': {'safe_curves': ['secp384r1', 'secp521r1']}
}
PQC_RECOMMENDATIONS = {
    'RSA': ['Kyber-1024', 'FrodoKEM-976-AES'],
    'EC': ['Kyber-512', 'Falcon-512']
}

def load_certificate(path):
    """Load a certificate (PEM or DER)."""
    data = open(path, 'rb').read()
    try:
        return x509.load_pem_x509_certificate(data, default_backend())
    except ValueError:
        return x509.load_der_x509_certificate(data, default_backend())

def assess_public_key(pub_key):
    """Assess key algorithm, size/curve, risk, and PQC suggestions."""
    if hasattr(pub_key, 'key_size'):  # RSA
        bits = pub_key.key_size
        risk = 'High' if bits < RISK_THRESHOLDS['RSA']['min_bits'] else 'Low'
        return {'algorithm': f'RSA-{bits}', 'risk': risk, 'recommendations': PQC_RECOMMENDATIONS['RSA']}


    if hasattr(pub_key, 'curve'):
        curve = pub_key.curve.name
        risk = 'High' if curve not in RISK_THRESHOLDS['EC']['safe_curves'] else 'Low'
        return {'algorithm': curve, 'risk': risk, 'recommendations': PQC_RECOMMENDATIONS['EC']}

    return {'algorithm': 'Unknown', 'risk': 'Unknown', 'recommendations': []}

def scan_directory(path):
    """Walk through the directory, find cert files, assess each."""
    results = []
    for root, _, files in os.walk(path):
        for fname in files:
            if fname.lower().endswith(('.pem', '.crt', '.cer', '.der')):
                fpath = os.path.join(root, fname)
                try:
                    cert = load_certificate(fpath)
                    pub = cert.public_key()
                    info = assess_public_key(pub)
                    info['file'] = fpath
                    results.append(info)
                except Exception as e:
                    print(f"[Error] {fpath}: {e}", file=sys.stderr)
    return results

def generate_report(results, out_path):
    """Create a Markdown report of findings."""
    with open(out_path, 'w') as rpt:
        rpt.write('# Quantum Readiness Scanner Report\n\n')
        for r in results:
            rpt.write(f"## {r['file']}\n")
            rpt.write(f"- Algorithm: {r['algorithm']}\n")
            rpt.write(f"- Risk Level: {r['risk']}\n")
            recs = ', '.join(r['recommendations']) or 'None'
            rpt.write(f"- Recommended PQC: {recs}\n\n")
    print(f"Report generated at: {out_path}")

def main():
    parser = argparse.ArgumentParser(description='Quantum Readiness Scanner')
    parser.add_argument('scan_path', help='Directory to scan for certs')
    parser.add_argument('-o', '--output', default='report.md', help='Output report filename')
    args = parser.parse_args()

    results = scan_directory(args.scan_path)
    generate_report(results, args.output)

if __name__ == '__main__':
    main()

