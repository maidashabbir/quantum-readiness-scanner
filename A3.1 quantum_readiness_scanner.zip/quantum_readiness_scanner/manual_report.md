# Quantum Readiness Scanner Report

## manual_certs\site.cer
- Algorithm: RSA-256
- Risk Level: High
- Recommended PQC: Kyber-1024, FrodoKEM-976-AES

