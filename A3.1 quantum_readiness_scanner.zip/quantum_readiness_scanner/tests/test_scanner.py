
import os
import pytest
import tempfile
import shutil
from scanner import assess_public_key, scan_directory
from cryptography.hazmat.primitives.asymmetric import rsa, ec

def generate_cert(tmp_dir, kind='rsa', bits=2048, curve='secp384r1'):
    from cryptography.x509 import CertificateBuilder, Name, NameAttribute, random_serial_number
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes
    from datetime import datetime, timedelta
    # generate key
    if kind=='rsa':
        key = rsa.generate_private_key(public_exponent=65537, key_size=bits)
    else:
        key = ec.generate_private_key(getattr(ec, curve)())
    pub = key.public_key()
    # build cert
    builder = CertificateBuilder()
    builder = builder.subject_name(Name([NameAttribute(NameOID.COMMON_NAME, 'test')]))
    builder = builder.issuer_name(Name([NameAttribute(NameOID.COMMON_NAME, 'test')]))
    builder = builder.not_valid_before(datetime.utcnow())
    builder = builder.not_valid_after(datetime.utcnow()+timedelta(days=1))
    builder = builder.serial_number(random_serial_number())
    builder = builder.public_key(pub)
    cert = builder.sign(key, hashes.SHA256())
    # write
    path = os.path.join(tmp_dir, f"test_{kind}.pem")
    with open(path,'wb') as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    return path

def test_assess_rsa_low():
    priv = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    info = assess_public_key(priv.public_key())
    assert info['risk']=='Low'
    assert 'RSA-4096' in info['algorithm']

def test_assess_rsa_high():
    priv = rsa.generate_private_key(public_exponent=65537, key_size=1024)
    info = assess_public_key(priv.public_key())
    assert info['risk']=='High'

def test_scan_directory(tmp_path):
    d = tmp_path / 'certs'
    d.mkdir()
    rsa_cert = generate_cert(str(d), 'rsa', bits=2048)
    ec_cert  = generate_cert(str(d), 'ec', curve='secp256r1')
    results = scan_directory(str(d))
    paths = [r['file'] for r in results]
    assert rsa_cert in paths
    assert ec_cert in paths